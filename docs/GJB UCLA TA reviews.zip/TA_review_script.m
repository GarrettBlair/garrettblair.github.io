% script to summarize all course reviews within the folder
% column M (13) corresponds to the question:
% "Overall – What is your overall rating of the teaching assistant?"
% score ranges from 0 to 9
ddir = 'C:\Users\gjb326\Documents\COURSES\Individual course reviews\';
% Note: one student review was manuall removed from "BLAIR_G.J._-_17S_PSYCH_116_LAB_3A" 
% because, as they stated, "Garrett was not my TA" and answered all 0's  :)
csvfiles = dir([ddir '*.csv']);
overallrating = [];
for i = 1:length(csvfiles)
    t = readtable([ddir  csvfiles(i).name], 'HeaderLines', 1, 'Range', 'M:M','Delimiter',',');
    overallrating = cat(1, overallrating, t.Var1);
end
%%
figure(123)
set(gcf, 'Position', [488.0000  530.6000  352.6000  227.2000])
histogram(overallrating, [-.5:1:9.5], 'FaceColor', [.3 .3 .3], 'FaceAlpha', .2)
hold on

title(sprintf('Overall TA rating: mean = %0.2f +/- %0.2f', ...
    nanmean(overallrating), nanstd(overallrating)))

axis([-.5 10 0 140])
set(gca, 'XTick', [0:9], 'YTick', [0:40:120])